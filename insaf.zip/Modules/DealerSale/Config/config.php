<?php

return [
    'name' => 'DealerSale'
];
