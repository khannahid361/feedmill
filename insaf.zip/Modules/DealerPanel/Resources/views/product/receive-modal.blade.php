<div class="modal fade" id="view_modal" tabindex="-1" role="dialog" aria-labelledby="model-1" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
      <div class="modal-content">
        <div class="modal-header bg-primary">
          <h3 class="modal-title text-white" id="model-1"><i class="fas fa-eye text-white"></i> <span>Receive Product</span></h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i aria-hidden="true" class="ki ki-close text-white"></i></button>
        </div>
        <div class="modal-body">
            <div class="row" id="view-data"></div>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-sm" id="save-btn" onclick="store_data()">Receive</button>
        </div>
      </div>
    </div>
  </div>
