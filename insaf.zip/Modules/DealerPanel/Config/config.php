<?php

return [
    'name' => 'DealerPanel'
];
