<?php

return [
    'name' => 'Dealer'
];
