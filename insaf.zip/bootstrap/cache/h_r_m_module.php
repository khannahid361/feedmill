<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\HRM\\Providers\\HRMServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\HRM\\Providers\\HRMServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);