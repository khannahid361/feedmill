<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Dealer\\Providers\\DealerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Dealer\\Providers\\DealerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);