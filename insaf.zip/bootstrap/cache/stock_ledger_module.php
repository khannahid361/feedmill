<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\StockLedger\\Providers\\StockLedgerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\StockLedger\\Providers\\StockLedgerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);