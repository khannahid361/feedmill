<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DealerSale\\Providers\\DealerSaleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DealerSale\\Providers\\DealerSaleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);