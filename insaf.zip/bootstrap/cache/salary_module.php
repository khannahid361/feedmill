<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Salary\\Providers\\SalaryServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Salary\\Providers\\SalaryServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);