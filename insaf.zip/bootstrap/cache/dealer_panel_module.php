<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DealerPanel\\Providers\\DealerPanelServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DealerPanel\\Providers\\DealerPanelServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);