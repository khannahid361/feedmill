<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Designation\\Providers\\DesignationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Designation\\Providers\\DesignationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);