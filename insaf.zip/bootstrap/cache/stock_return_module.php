<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\StockReturn\\Providers\\StockReturnServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\StockReturn\\Providers\\StockReturnServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);