<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Location\\Providers\\LocationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Location\\Providers\\LocationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);